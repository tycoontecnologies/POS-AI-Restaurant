// categories_screen.dart
import 'package:flutter/material.dart';
import 'package:pos/components/ui/shimmer_effect.dart';
import 'package:provider/provider.dart';
import 'package:pos/l10n/app_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';
import '../models/category.dart';
import '../providers/category_provider.dart';
import '../components/ui/custom_button.dart';
import '../components/ui/custom_card.dart';
import '../components/ui/custom_input.dart';
import '../components/ui/status_badge.dart';
import '../components/ui/data_table_widget.dart';
import '../components/ui/search_bar_widget.dart';
import '../utils/app_spacing.dart';
import '../utils/app_colors.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  // Tutorial coach mark controller and targets
  TutorialCoachMark? tutorialCoachMark;
  final GlobalKey _addButtonKey = GlobalKey();
  final GlobalKey _searchBarKey = GlobalKey();
  final GlobalKey _categoriesTableKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _checkIfHasData();
    _checkAndShowTutorial();

    _searchController.addListener(_onSearchChanged);

    // Load initial data
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final categoryProvider = context.read<CategoryProvider>();
      categoryProvider.loadInitialCategories();
    });

    // Setup scroll listener for pagination
    _scrollController.addListener(_onScroll);
  }

  Future<void> _checkAndShowTutorial() async {
    final prefs = await SharedPreferences.getInstance();
    final hasSeenTutorial = prefs.getBool('categories_tutorial_seen') ?? false;

    if (!hasSeenTutorial) {
      // Wait for the UI to build before showing the tutorial
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Future.delayed(const Duration(milliseconds: 500), () {
          _showTutorial(context);
          prefs.setBool('categories_tutorial_seen', true);
        });
      });
    }
  }

  void _showTutorial(BuildContext context) {
    tutorialCoachMark = TutorialCoachMark(
      targets: _createTargets(),
      colorShadow: Colors.black12,
      textSkip: "SKIP",
      paddingFocus: 10,
      opacityShadow: 0.8,
      onFinish: () {
        print("Tutorial completed");
      },
      onClickTarget: (target) {
        print(target);
      },
      onSkip: () {
        print("Tutorial skipped");
        return true;
      },
    );

    tutorialCoachMark!.show(context: context); // ✅ context required here
  }

  List<TargetFocus> _createTargets() {
    return [
      TargetFocus(
        identify: "add_button",
        keyTarget: _addButtonKey,
        contents: [
          TargetContent(
            align: ContentAlign.bottom,
            builder: (context, controller) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    "Add Category",
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Tap here to create your first category. Categories help organize your products.",
                    style: Theme.of(
                      context,
                    ).textTheme.bodyMedium?.copyWith(color: Colors.white),
                  ),
                ],
              );
            },
          ),
        ],
        shape: ShapeLightFocus.RRect,
        radius: 8,
      ),
      TargetFocus(
        identify: "search_bar",
        keyTarget: _searchBarKey,
        contents: [
          TargetContent(
            align: ContentAlign.bottom,
            builder: (context, controller) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Search Categories",
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Use this search bar to quickly find categories by name.",
                    style: Theme.of(
                      context,
                    ).textTheme.bodyMedium?.copyWith(color: Colors.white),
                  ),
                ],
              );
            },
          ),
        ],
        shape: ShapeLightFocus.RRect,
        radius: 8,
      ),
      TargetFocus(
        identify: "categories_table",
        keyTarget: _categoriesTableKey,
        contents: [
          TargetContent(
            align: ContentAlign.top,
            builder: (context, controller) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "Categories List",
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Here you'll see all your categories. You can edit or delete them using the action buttons.",
                    style: Theme.of(
                      context,
                    ).textTheme.bodyMedium?.copyWith(color: Colors.white),
                  ),
                ],
              );
            },
          ),
        ],
        shape: ShapeLightFocus.RRect,
        radius: 8,
      ),
    ];
  }

  Future<void> _checkIfHasData() async {
    final categoryProvider = context.read<CategoryProvider>();
    await categoryProvider.loadInitialCategories();
    setState(() {
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    _searchController.removeListener(_onSearchChanged);
    _scrollController.removeListener(_onScroll);
    tutorialCoachMark?.finish();
    super.dispose();
  }

  void _onSearchChanged() {
    final categoryProvider = context.read<CategoryProvider>();
    categoryProvider.searchCategories(_searchController.text);
  }

  void _onScroll() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _loadMoreCategories();
    }
  }

  void _loadMoreCategories() async {
    final categoryProvider = context.read<CategoryProvider>();
    if (!categoryProvider.isLoading && categoryProvider.hasMore) {
      await categoryProvider.loadMoreCategories();
    }
  }

  void _createOrEdit({Category? item}) async {
    final l10n = AppLocalizations.of(context)!;
    final categoryProvider = context.read<CategoryProvider>();

    final formKey = GlobalKey<FormState>();
    final controller = TextEditingController(text: item?.name ?? '');
    bool isActive = item?.active ?? true;

    final result = await showDialog<_CategoryFormResult>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: const Color(0xFFFDFDFE),
              surfaceTintColor: Colors.transparent,
              title: Text(item == null ? l10n.addCategory : l10n.editCategory),
              content: SizedBox(
                width: 400,
                child: Form(
                  key: formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CustomInput(
                        label: l10n.name,
                        controller: controller,
                        hint: 'Enter category name',
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Category name is required';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: AppSpacing.md),
                      Row(
                        children: [
                          Text(
                            l10n.active,
                            style: Theme.of(context).textTheme.labelLarge,
                          ),
                          const Spacer(),
                          Switch(
                            value: isActive,
                            onChanged: (v) =>
                                setDialogState(() => isActive = v),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                CustomButton(
                  text: l10n.cancel,
                  variant: ButtonVariant.text,
                  onPressed: () => Navigator.pop(context),
                ),
                CustomButton(
                  text: l10n.save,
                  onPressed: () {
                    // ✅ Validate before proceeding
                    if (formKey.currentState?.validate() ?? false) {
                      Navigator.pop(
                        context,
                        _CategoryFormResult(
                          name: controller.text.trim(),
                          active: isActive,
                        ),
                      );
                    }
                  },
                ),
              ],
            );
          },
        );
      },
    );

    if (result == null) return;

    try {
      if (item == null) {
        // Create new category with auto-generated ID (will be set in service)
        final newCategory = Category(
          id: '', // Will be auto-generated
          name: result.name,
          active: result.active,
        );

        final success = await categoryProvider.addCategory(newCategory);
        if (success && mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              duration: Duration(seconds: 1),
              content: Text('Category added successfully'),
              backgroundColor: AppColors.success,
            ),
          );

          // Check if this was the first category added
          // if (item == null) {
          //   final prefs = await SharedPreferences.getInstance();
          //   final hasSeenProducts =
          //       prefs.getBool('onboarding_products_seen') ?? false;

          //   if (!hasSeenProducts) {
          //     // Navigate to products screen after a short delay
          //     Future.delayed(const Duration(milliseconds: 500), () {
          //       if (mounted) {
          //         context.go(AppRouter.products);
          //       }
          //     });
          //   }
          // }
        }
      } else {
        // Update existing category
        final updatedCategory = item.copyWith(
          name: result.name,
          active: result.active,
        );

        final success = await categoryProvider.updateCategory(updatedCategory);
        if (success && mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              duration: Duration(seconds: 1),
              content: Text('Category updated successfully'),
              backgroundColor: AppColors.success,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            duration: Duration(seconds: 1),
            content: Text('Error: $e'),
            backgroundColor: AppColors.error,
          ),
        );
      }
    }
  }

  void _delete(Category item) async {
    final l10n = AppLocalizations.of(context)!;
    final categoryProvider = context.read<CategoryProvider>();

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFDFDFE),
        surfaceTintColor: Colors.transparent,
        title: Text(l10n.deleteConfirmTitle('Category')),
        content: Text(l10n.deleteConfirmMessage(item.name)),
        actions: [
          CustomButton(
            text: l10n.cancel,
            variant: ButtonVariant.text,
            onPressed: () => Navigator.pop(context, false),
          ),
          CustomButton(
            text: l10n.delete,
            color: AppColors.error,
            onPressed: () => Navigator.pop(context, true),
          ),
        ],
      ),
    );

    if (ok == true) {
      try {
        final success = await categoryProvider.deleteCategory(item.id);
        if (success && mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Category deleted successfully'),
              backgroundColor: AppColors.success,
            ),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              duration: Duration(seconds: 1),
              content: Text('Error deleting category: $e'),
              backgroundColor: AppColors.error,
            ),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final categoryProvider = context.watch<CategoryProvider>();

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [

          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      l10n.categories,
                      style: Theme.of(context).textTheme.headlineMedium
                          ?.copyWith(
                            fontWeight: FontWeight.w700,
                            color: AppColors.grey800,
                          ),
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    Text(
                      'Manage your product categories',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppColors.grey600,
                      ),
                    ),
                  ],
                ),
              ),
              CustomButton(
                key: _addButtonKey, // Added key for tutorial
                text: l10n.addCategory,
                icon: Icons.add,
                onPressed: () => _createOrEdit(),
              ),
            ],
          ),

          const SizedBox(height: AppSpacing.md),

          SearchBarWidget(
            key: _searchBarKey, // Added key for tutorial
            controller: _searchController,
            hint: 'Search categories...',
            onChanged: (_) => _onSearchChanged(),
            onClear: () {
              _searchController.clear();
              _onSearchChanged();
            },
          ),
          const SizedBox(height: AppSpacing.sm),

          Expanded(
            key: _categoriesTableKey, // Added key for tutorial
            child: _buildContent(categoryProvider, l10n),
          ),
        ],
      ),
    );
  }

  Widget _buildContent(CategoryProvider provider, AppLocalizations l10n) {
    if (provider.isLoading && provider.categories.isEmpty) {
      return _buildShimmerTable();
    }

    if (provider.error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error, size: 64, color: AppColors.error),
            const SizedBox(height: AppSpacing.md),
            Text('Error: ${provider.error}'),
            const SizedBox(height: AppSpacing.md),
            CustomButton(
              text: 'Retry',
              onPressed: () => provider.loadInitialCategories(),
              variant: ButtonVariant.filled,
            ),
          ],
        ),
      );
    }

    final categories = provider.categories;

    if (categories.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.category, size: 64, color: Colors.grey),
            const SizedBox(height: AppSpacing.md),
            Text(
              _searchController.text.isEmpty
                  ? 'No categories found'
                  : 'No categories found for "${_searchController.text}"',
              style: TextStyle(fontSize: 18, color: Colors.grey.shade600),
            ),
          ],
        ),
      );
    }

    return NotificationListener<ScrollNotification>(
      onNotification: (scrollNotification) {
        if (scrollNotification is ScrollEndNotification &&
            _scrollController.position.pixels ==
                _scrollController.position.maxScrollExtent) {
          _loadMoreCategories();
        }
        return false;
      },
      child: SingleChildScrollView(
        controller: _scrollController,
        child: DataTableWidget(
          columns: const [
            DataColumn(
              label: Text('#', style: TextStyle(fontWeight: FontWeight.w600)),
            ),
            DataColumn(
              label: Text(
                'Name',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            DataColumn(
              label: Text(
                'Status',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            DataColumn(
              label: Text(
                'Created On',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            DataColumn(
              label: Text(
                'Actions',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          ],
          rows: categories
              .asMap()
              .entries
              .map(
                (e) => DataRow(
                  cells: [
                    DataCell(Text('${e.key + 1}')),
                    DataCell(Text(e.value.name)),
                    DataCell(
                      StatusBadge(
                        text: e.value.active ? l10n.active : l10n.inactive,
                        variant: e.value.active
                            ? BadgeVariant.success
                            : BadgeVariant.neutral,
                      ),
                    ),
                    DataCell(
                      Text(
                        e.value.createdOn.toIso8601String().substring(0, 10),
                      ),
                    ),
                    DataCell(_rowActions(e.value)),
                  ],
                ),
              )
              .toList(),
          mobileItemBuilder: (context, index) {
            final item = categories[index];
            return CustomCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          item.name,
                          style: Theme.of(context).textTheme.titleMedium
                              ?.copyWith(fontWeight: FontWeight.w600),
                        ),
                      ),
                      StatusBadge(
                        text: item.active ? l10n.active : l10n.inactive,
                        variant: item.active
                            ? BadgeVariant.success
                            : BadgeVariant.neutral,
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  Text(
                    'ID: ${item.id} • Created: ${item.createdOn.toIso8601String().substring(0, 10)}',
                    style: Theme.of(
                      context,
                    ).textTheme.bodySmall?.copyWith(color: AppColors.grey600),
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [_rowActions(item)],
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _rowActions(Category item) {
    final l10n = AppLocalizations.of(context)!;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        IconButton(
          tooltip: l10n.edit,
          icon: const Icon(Icons.edit, size: 18),
          onPressed: () => _createOrEdit(item: item),
          style: IconButton.styleFrom(
            backgroundColor: AppColors.primary.withOpacity(0.1),
            foregroundColor: AppColors.primary,
          ),
        ),
        const SizedBox(width: AppSpacing.xs),
        IconButton(
          tooltip: l10n.delete,
          icon: const Icon(Icons.delete, size: 18),
          onPressed: () => _delete(item),
          style: IconButton.styleFrom(
            backgroundColor: AppColors.error.withOpacity(0.1),
            foregroundColor: AppColors.error,
          ),
        ),
      ],
    );
  }

  Widget _buildShimmerTable() {
    return DataTableWidget(
      columns: const [
        DataColumn(label: ShimmerEffect(width: 20, height: 20)),
        DataColumn(label: ShimmerEffect(width: 80, height: 20)),
        DataColumn(label: ShimmerEffect(width: 60, height: 20)),
        DataColumn(label: ShimmerEffect(width: 80, height: 20)),
        DataColumn(label: ShimmerEffect(width: 60, height: 20)),
      ],
      rows: List.generate(
        5,
        (index) => DataRow(
          cells: [
            DataCell(ShimmerEffect(width: 20, height: 20)),
            DataCell(ShimmerEffect(width: 120, height: 20)),
            DataCell(ShimmerEffect(width: 60, height: 20)),
            DataCell(ShimmerEffect(width: 80, height: 20)),
            DataCell(
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ShimmerEffect(
                    width: 36,
                    height: 36,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  SizedBox(width: AppSpacing.xs),
                  ShimmerEffect(
                    width: 36,
                    height: 36,
                    borderRadius: BorderRadius.circular(18),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      mobileItemBuilder: (context, index) {
        return CustomCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: ShimmerEffect(width: double.infinity, height: 20),
                  ),
                  SizedBox(width: AppSpacing.sm),
                  ShimmerEffect(
                    width: 60,
                    height: 24,
                    borderRadius: BorderRadius.circular(12),
                  ),
                ],
              ),
              SizedBox(height: AppSpacing.sm),
              ShimmerEffect(width: 200, height: 14),
              SizedBox(height: AppSpacing.sm),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  ShimmerEffect(
                    width: 36,
                    height: 36,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  SizedBox(width: AppSpacing.xs),
                  ShimmerEffect(
                    width: 36,
                    height: 36,
                    borderRadius: BorderRadius.circular(18),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _CategoryFormResult {
  _CategoryFormResult({required this.name, required this.active});
  final String name;
  final bool active;
}
